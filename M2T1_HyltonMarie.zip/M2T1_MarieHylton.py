#CSC 221
#M2T1:
#Bronze Silver Gold]

''' [Author:  Marie Hylton]
This program counts the number of times
the letter T (uppercase or lowercase) appears in a string.'''
import string
def main():
    #Run the menus.
    menu1()
    menu2()
    
def menu1():
    '''Runs the has_which_vowel menu.'''
    
    my_string = input('Enter a sentence: ')
    my_string=my_string.lower()
    #Checks for input validation if not, runs vowel function.
    if my_string.isdigit():
        print("Enter a valid response.")
        menu1()
    vowels,count=has_which_vowels(my_string)

    # Print the result.
    if len(vowels)==0:
        print("The given sentence contains no vowels.")
    else:
        print("The given sentence contains the following vowels: ",vowels)
        print('Those vowels appear', count, 'times in the sentence.')
    return my_string

    
def menu2():
    '''Runs the has_which_letter menu'''
    # Get a list from the user.
    my_list=input('Enter a list of letters: ')
    #Checks for input validation, if not, runs letter function.
    my_list=my_list.lower()
    if my_list.isdigit():
        print("Enter a valid response.")
        menu2()
    letterList,letterSet,letterSingle,count=has_which_letters(my_list)
    #Print the result.
    if len(letterSet)==0:
        print("There aren't any letters present.")
        exit
    elif len(letterSet)==1:
        print("The letter is present one time.")
        exit
    else:
        print("There are ",len(letterSet)," letters which are: ",letterSet)
        print("The letters appear a total of ",count,"times in the list.")
    countletters(letterList, letterSet)
    return my_list

def has_which_vowels(my_string):
    '''Create a set to hold the vowels. Create a variable to hold the vowel count.'''
    vowels= set()
    count = 0
    
    # Record and count the vowels.
    for ch in my_string:
        if ch == 'a' or ch  == 'e' or ch=='i' or ch=='o' or ch=='u':
            count += 1
            vowels.add(ch)
    return vowels, count    

def has_which_letters(my_list):
    '''Uses a combo of sets and lists to hold the letters Create a variable to see frequency of letters in string''' 
    letterList=[]
    letterSet=list()
    letterSingle=set()
    my_list=my_list.lower()
    my_list=my_list.replace(" ","")
    count=0
    for letter in my_list:
        if letter in string.ascii_lowercase:
            letterList.append(letter)
            letterSingle.add(letter)
            count+=1

    for ch in letterSingle:
        letterSet.append(ch)   
    return letterList,letterSet, letterSingle,count      

    
def countletters(letterList, letterSet):
    '''Counts the number of times letters are in the string'''
    print("Out of the letters:  ",letterSet)
    val=0
    letterList.sort()
    for var in letterSet:
        val=letterList.count(var)
        if val>1:
            print(var,"is in the list", val, "times.")
        elif val==1:
            print(var, "is in the list", val, "time.")               
#main()

if __name__ =='__main__':
    main()
