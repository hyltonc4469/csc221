

#pytest from the terminal
#pytest -q test_M2T1_MarieHylton.py
'''looks for test in this folder in quiet mode'''

import string
from M2T1_MarieHylton import has_which_vowels
from M2T1_MarieHylton import has_which_letters

def test_NoVowels():
    '''tests a string with some vowels'''
    string='vwls'
    vowels,count=has_which_vowels(string)
    assert (0== len(vowels))
    
def test_AllVowels():
    '''tests a string with all vowels'''
    string='aeiou'
    vowels,count=has_which_vowels(string)
    assert (len(string))==5
    
def test_EmptyVowelString():
    '''tests a string with no vowels'''
    string=''
    vowels=has_which_vowels(string)
    assert(0==(len(string)))
    
def test_SomeVowels():
    '''tests a string with some vowels'''
    string='some vowels'
    vowels=has_which_vowels(string)
    assert 5>(len(vowels))
    
def test_NoLetters():
    '''tests a string with no letters'''
    letters='1234'
    alphabet=[]
    for ch in string.ascii_letters:
        alphabet.append(ch)
    letterSingle=has_which_letters(letters)
    if letterSingle not in alphabet:
        assert True

def test_EmptyLetterString():
    '''tests a string with no alpha-characters'''
    stri=''
    alphabet=[]
    letterList=has_which_letters(stri)
    for ch in string.ascii_letters:
        alphabet.append(ch)
    if letterList not in alphabet:
        assert True

def test_AllLetters():
    '''tests a string with all letters'''
    allLetters=[]
    stri=[]
    for ch in string.ascii_lowercase:
        allLetters.append(ch)
        stri.append(ch)
    if 26==len(stri)==len(allLetters):
        assert True

def test_SomeLetters():
    '''tests a string with some letters'''
    string='abcdefg'
    letterSingle=has_which_letters(string)
    assert 26>(len(string))
    
def test_Punctuation():
    '''tests a string that don't test for any letters at all'''
    test='.'
    string.punctuation
    if test in string.punctuation:
        assert True
        
def test_NormalCase():
    '''tests a typical string for letters'''
    test='Jesus lives.'
    letterSingle=has_which_letters(test)
    for ch in letterSingle:
        if ch=="a" or ch=="e" or ch=="i" or ch=="o" or ch=="u":
            assert False
    
#if __name__ =='__main__':
#    main()
