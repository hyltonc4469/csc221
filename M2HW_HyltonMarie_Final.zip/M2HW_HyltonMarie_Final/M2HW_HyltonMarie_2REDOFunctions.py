#CSC221
#September 28
#HyltonM

from operator import itemgetter
import pickle

def main():
    words=openFile()
    menu()
    pokeList=createPokeList(words)
    pokemonSearch=searchPokemon(words)
    pokeDict=createDictionary(pokemonSearch)
    pokemonData=displayData(words)
    chooseMenuItem(words,pokeList,pokemonSearch,pokeDict,pokemonData)
    
def menu():
    '''Displays the main menu'''
    print("1.  List all Pokemon\n2.  Search for a Pokemon\n3.  Search Dictionary")
    print("4.  Save Pokemon Data/Load Pokemon Data\n5.  Display Sorted Pokemon Data\n6.  Exit")

def chooseMenuItem(words,pokeList,pokemonSearch,pokeDict,pokemonData):
    '''User Options for the main menu.  Options`move user to a different function'''
    print()
    #Retrieve choice from user, send to corresponding function.
    do='y'
    choice='1'
    while do.lower=='y' or choice=='1'or choice=='2'or choice=='3'or choice=='4'or choice=='5'or choice=='6':
        choice=input("Enter a number that corresponds with your choice:  ")
        if choice=="1":
            print("Pokemon List: \n",len(pokeList),"items found in the list.\nThe listed pokemon are: ",pokeList,"\n")
        elif choice=="2":
            print("Pokemon Search: \n")
            findPokeSearch(pokemonSearch)
        elif choice=="3":
            print("Pokemon Dictionary: \n")
            findPokeDict(pokeDict,pokeList)
        elif choice=="4":
            print("Save/Load Pokemon Data: \n1.  Pokemon List: a pokemon list\n2.  Pokemon Dictionary: dictionary of pokemon/attributes\n3.  Sorted Pokemon List: ordered list of pokemon/attributes")
            saveFiles(pokemonSearch, pokeDict, pokemonData)
        elif choice=="5":
            print("Pokemon Data: \nPrints all pokemon data line by line and in ABC order.")
            spacing='{:<20}{:<20}{:<20}'
            print(spacing.format("Name:","Height:","Weight:"))
            for val in pokemonData:
                print(spacing.format(val[1],val[2],val[3]))
        elif choice=="6":
            print("Exit Pokemon Program: ")
            print("Goodbye!")
            break
        else:
            print("Enter a valid choice.")
        print()
        menu()
        do=input("Would you like to choose from the menu options? Enter: (y/n) ")
        if do.lower()!='y' and do.lower()!='n':
            print("Enter a valid choice.")
            chooseMenuItem(words,pokeList,pokemonSearch,pokeDict,pokemonData)
        if do.lower()=='n':
            print("Exit Pokemon Program:  \nGoodbye!")
            break
        
def openFile():
    '''Open and read the items in the file.
    Input: filename-csv file   Output: words-string of the entire file.'''
    filename="pokemon2.csv"
    with open(filename) as file:
        words=file.read().replace("\n", ",").split(",")
    return words

def createPokeList(words):
    '''Create a list of the names in the file.
    Input: words-string of the entire file.  Output: pokeList-list of the pokemon names.'''
    start=9
    index=0
    pokeList=[]
    while index<151:
        pokeList.append(words[start])
        start+=8
        index+=1
    return pokeList
    
def searchPokemon(words):
    """Creates a list of the 151 records in the list
    Input: words, a search string
    Output: pokemonSearch: a list of lists of all pokemon and their attributes"""
    #Pull needed entries for the list.
    beg=8
    end=13
    middle=11
    discard=10
    element=0
    pokemonSearch=[]
    while element<151: 
        pokemonSearch.append(words[beg:discard]+words[middle:end])
        beg+=8
        end+=8
        middle+=8
        discard+=8
        element+=1
    return pokemonSearch

def findPokeSearch(pokemonSearch):
    '''Searches for the user's pokemon.  Formats the results.
    Input:pokemonSearch-list of lists of pokemon and attributes
    Output: Matches the user's search or subsearch'''
    #Format
    spacing='{:<10}'*8
    #Instructions/Retrieve User's Entry
    print("Note: If an invalid entry is entered, you'll be returned to the main menu.")
    #Search for the entry.
    search=input("Enter the name of a pokemon: ")
    search=search.lower()
    for val in pokemonSearch:
        if search in val[1]:
            print(spacing.format("ID: ",val[0],"Name: ",val[1],"Height: ", val[2],"Weight: ", val[3],"\n"))
            
def findPokeDict(pokeDict,pokeList):
    '''Searches for an exact pokemon using a pokemon dictionary, formats the results.
    Input: pokeDict-dictionary of the pokemon, pokeList-list of the pokemon'''
    #Instructions.  Retrieve user's entry
    print("Note:  If an invalid entry is entered, you'll be returned to the main menu.")
    search=input("Enter the exact name of a pokemon: ")
    search=search.lower()
    if search not in pokeList:
        print(search, " not found!")
    for key, value in pokeDict.items():
        if search==key:
            print("\nSearch found!",key,value,)
            spacing='{:<15}'*8
            print(spacing.format("\nName: ",key,"\nID: ", value[0],"\nHeight: ",value[2],"\nWeight: ",value[3]))
           
def createDictionary(pokemonSearch):
    '''Creates a pokemon dictionary using pokemonSearch list.
    Input: pokemonSearch-list of lists of pokemon, Output: pokeDict-pokemon dictionary'''
    #Create dictionary and key/value pairs
    pokeDict={}
    for val in pokemonSearch:
        pokeDict[val[1]]=val[0:4]
    return pokeDict

def displayData(words):
    '''Creates a display of the pokemon list in ABC order. 
    Input: words-string of the file, Output: pokemonData-list in ABC order'''
    #Create list and order by name (index1)
    pokemonData=[]
    pokemonSearch=searchPokemon(words)
    pokemonData=sorted(pokemonSearch, key=itemgetter(1))
    return pokemonData

def saveFiles(pokemonSearch, pokeDict, pokemonData):
    '''Writes and saves three docs to separate files.
    Input: pokemonSearch--list of pokemon, pokeDict--dictionary of pokemon, pokemonData--pokemon in a list, ABC order
    Holds user choices in a set and can reload specific files
    when load function is called.'''
    again='y'
    save='1'
    savedFiles=set()
    while again.lower=='y' or save=='1' or save=='2' or save=='3':
        save=input("What would you like to save: Enter (1,2, or 3)")
        if save=='1':
            savedFiles.add(save)
            
            readWriteSearch(pokemonSearch)
            print("--SAVING-- \nData saved to 'pokemonSearchList.dat'")
        elif save=='2':
            savedFiles.add(save)
            readWriteDict(pokeDict)
            print("--SAVING-- \nData saved to 'pokemonDictionary.dat'")
        elif save=='3':
            savedFiles.add(save)
            readWriteData(pokemonData)
            print("--SAVING-- \nData saved to 'pokemonData.dat'")
        elif save!='1' or save!='2' or save!='3':
            print("Valid responses only.")
            saveFiles(pokemonSearch, pokeDict, pokemonData)
        again=input("Save more data? Enter(y/n)")
        if again.lower()!='y' and again.lower()!='n':
            print("Enter a valid response.")
            saveFiles(pokemonSearch, pokeDict, pokemonData)
        if again.lower()=='n':
            loadFiles(savedFiles,pokemonSearch, pokeDict, pokemonData)
            break

def loadFiles(savedFiles,pokemonSearch, pokeDict, pokemonData):
    '''Reads and loads docs chosen by the user.
   Input: pokemonSearch--list of pokemon, pokeDict--dictionary of pokemon
    pokemonData--pokemon in a list, ABC order, savedFiles--set of user choices that correlate with files.'''
    load='1'
    view='y'
    print("Save/Load Pokemon Data:")
    print("1. Pokemon List\t\t 2.  Pokemon Dictionary\t\t 3.  Sorted Pokemon List")
    while view.lower=='y' or load=='1' or load=='2' or load=='3':
        load=input("What file would you like to load:  Enter (1,2, or 3)")
        if load=='1':
            if load not in savedFiles:
                print("You did not choose to save that file.")
            else:
                filesearch=readWriteSearch(pokemonSearch)
                print("--LOADING--\n",filesearch)
        elif load=='2':
            if load not in savedFiles:
                print("You did not choose to save that file.")
            else:
                filedict=readWriteDict(pokeDict)
                print("--LOADING--\n",filedict)
        elif load=='3':
            if load not in savedFiles:
                print("You did not choose to save that file.")
            else:
                filedata=readWriteData(pokemonData)
                print("--LOADING--\n",filedata)
        elif load!='1' or load!='2' or load!='3':
            print("Valid responses only.")
            loadFiles(again,pokemonSearch, pokeDict, pokemonData)#savedFiles
        view=input("Load more data?  Enter (y/n)")
        if view.lower()!='y' and view.lower()!='n':
            print("Enter a valid response.")
            loadFiles(pokemonSearch, pokeDict, pokemonData)#savedFiles
        if view.lower()=='n':
            print("Data can be viewed at your pleasure.")
            break           

def readWriteData(pokemonData):
    datafile=open('pokemonData.dat','wb')
    pickle.dump(pokemonData, datafile)
    datafile.close()
    datafile=open('pokemonData.dat','rb')
    filedata=pickle.load(datafile)
    datafile.close()
    return filedata

def readWriteDict(pokeDict):
    dictfile=open('pokemonDictionary.dat','wb')
    pickle.dump(pokeDict, dictfile)
    dictfile.close()
    dictfile=open('pokemonDictionary.dat','rb')
    filedict=pickle.load(dictfile)
    dictfile.close()
    return filedict

def readWriteSearch(pokemonSearch):
    searchfile=open('pokemonSearchList.dat','wb')
    pickle.dump(pokemonSearch,searchfile)
    searchfile.close()
    searchfile=open('pokemonSearchList.dat','rb')
    filesearch=pickle.load(searchfile)
    searchfile.close()
    return filesearch

main()

