
import string
import unittest
import M2T1Hylton as file

class TestMe(unittest.TestCase):

    def test_NoVowels(self):
        '''tests a string without vowels'''
        string='vwls'
        vowels,count=file.has_which_vowels(string)
        self.assertEqual(0,len(vowels))

    def test_SomeVowels(self):
        '''tests a string with some vowels'''
        string='some vowels'
        vowels=file.has_which_vowels(string)
        self.assertGreater(5,(len(vowels)))

    def test_AllVowels(self):
        '''tests a string with all vowels'''
        string='aeiou'
        vowels,count=file.has_which_vowels(string)
        self.assertEqual(5,len(vowels))

    def test_EmptyString(self):
        '''tests a string with no characters'''
        string=''
        self.assertEqual(0,(len(string)))

    def test_NoLetters(self):
        '''tests a string with no leters'''
        letters='1234'
        alphabet=[]
        for ch in string.ascii_letters:
            alphabet.append(ch)
        letterSingle=file.has_which_letters(letters)
        if letterSingle not in alphabet:
            self.assertTrue
            
    def test_EmptyLetterString(self):
        '''tests a string with no alpha-characters'''
        stri=''
        alphabet=[]
        for ch in string.ascii_letters:
            alphabet.append(ch)
        if stri not in alphabet:
            self.assertTrue
            
    def test_AllLetters(self):
        '''tests a string with all letters'''
        allLetters=[]
        stri=[]
        for ch in string.ascii_lowercase:
            allLetters.append(ch)
            stri.append(ch)
        if 26==len(stri)==len(allLetters):
            self.assertTrue

    def test_SomeLetters(self):
        '''tests a string with some letters'''
        string='abcdefg'
        letterList=file.has_which_letters(string)
        self.assertGreater(26,(len(letterList)))
    
    def test_Punctuation(self):
        '''tests a string that don't test for any letters at all'''
        test='.'
        string.punctuation
        if test in string.punctuation:
            self.assertTrue
        
    def test_NormalCase(self):
        '''tests a typical string for letters'''
        test='Jesus lives.'
        letterSingle=file.has_which_letters(test)
        for ch in letterSingle:
            if ch=="a" or ch=="e" or ch=="i" or ch=="o" or ch=="u":
                self.assertFalse
                
if __name__=='__main__':
    unittest.main()
                           
 
