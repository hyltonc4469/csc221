//CIS 115
//M1Lab
//Name and Age Conversation
//Marie Hylton

/* The Plan:
* Ask the user their name.
* Say it back.
* Ask their age.
* Add one to it.
* Say it back.
*/

package m1lab_hyltonmarie;

import java.util.Scanner;
public class M1LAB_HyltonMarie {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      //Create Scanner object.
    Scanner keyboard=new Scanner (System.in);

    //Declare Variables
    String name, birthdayMonth;
    int age, newAge;
    String getName="Hi.  My name is Java.  What's your name?";    
    //Get the user's name.
    System.out.println(getName);
    name=keyboard.nextLine();

    //Return name.
    System.out.println("Hi, "+ name+"!");

    //Get the user's age.
    //System.out.println(" How old are you, " + name+"?");
    //age=keyboard.nextInt();

    //Calculate new age.
   // newAge=age+1;

    //Display user's information.
    //System.out.println(name+ ", today you are "+ age+" years old. "
      //      + "Next year, you will be "+newAge+" years old.");

    
    //public static void [] getARray()
    
    //String[] months={"January", "February", "March", "April", "May", "June",
     //   "July", "August", "September", "October", "November", "December"};
    
    //int[] number={1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};
   // int index=0;
    
    
    
    System.out.println("01=January"); System.out.println("02=February");
    System.out.println("03=March");System.out.println("04=April");
    System.out.println("05=May");System.out.println("06=June");
    System.out.println("07=July");System.out.println("08=August");
    System.out.println("08=September");System.out.println("10=October");
    System.out.println("11=November");System.out.println("12=December");
    System.out.println("What month were you born in?  Please enter the "
            + "month number only.");
    int birthMonth=keyboard.nextInt();
    System.out.println("What year were you born?");
    int birthYear=keyboard.nextInt();
    int currentYear=2018;
    int currentMonth=9;
    age=(currentYear-birthYear);
    newAge=age+1;
    if (birthMonth<currentMonth)
    {   System.out.println("You already had a birthday this year.  Since you "
                + "are "+age+" now, "+name+", you will turn "+newAge+" years old"
                        + " next year.");}
    else if (birthMonth>currentMonth)
    {   age=age-1;newAge=age+1;
        System.out.println("You haven't had a birthday this year, "
                + "but it's coming up soon!  Since you are "
                + age+" now, "+name+", you will be turning "+newAge+" years old"
                        + " by the end of the year.");}
    
   else if (birthMonth==currentMonth) 
   {    age=age-1; newAge=age+1;
       System.out.println("This is your birthday month!  Hurray!");
   
        System.out.println("This month you will stop being " +age+ " years old"
                + " and you will turn " +newAge+", "+name+".");}
    
    
    
    
    
    
   // if (birthdayMonth!=months[index])
        //System.out.println("Please enter a valid month.");
       //index++;
        //birthdayMonth=months.get[index];
       // System.out.println(birthdayMonth);
    
        
    
    
    
    
    
 //   for (int index=0; index<months.length; index++)
    {
      //  System.out.println(months[index] + "has"+ number[index]+ "days.");
    }
    }
    
    }
            
    
            
   
  
