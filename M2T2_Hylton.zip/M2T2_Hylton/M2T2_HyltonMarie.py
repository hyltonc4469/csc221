#CSC 221
#October 6, 2018
#HyltonM
'''
This program: 'uploads' a file from the user, pickles the file for saving,
unpickles the file,sorts the data by name and gpa.  This program also
attempts to 'catch' expected errors with try/excepts and user validation
statements.
'''
import csv#processing data
import pickle#serialize//deserialize file
spacing='{:<20}'*2#formats data
def main():
    '''runs file retrieval and menu functions'''
    filename,contents=getFile()
    selectMenu(filename,contents)

def getFile():
    '''Gets file name from user.  Validates directory path'''
    filename=input("Enter the filename: ")
    try:
        infile=open(filename, 'r')
        contents=infile.readlines()
        infile.close()
        print("File found!")
        return filename,contents#Returns filename and contents, used in menu.
    except FileNotFoundError:
        print(filename," not found in directory. Please try again.")
        main()
        
def saveFile(contents):
    '''serializes file line by line'''
    outfile=open('studentData.dat','wb')
    for record in contents:
        pickle.dump(record, outfile)
    outfile.close()
    
def loadFile():
    '''deserializes file line by line, stripping new lines'''
    records=[]#creates a list to hold items
    eof=False#End of File variable
    infile=open('studentData.dat', 'rb')
    while not eof:#Runs a loop until the eof is reached
        try:
            record=pickle.load(infile)
            records.append(record.rstrip('\n'))
        except EOFError:
            eof=True
    infile.close()
    
def reader(contents):
    '''Input: contents-list of data in file. Output: records-lists of lists of data'''
    skipHeader=True#var for eliminating header
    NAME=0#first item in list
    MAJOR=1#second item in list, not used
    GPA=2#third item in list
    records=[]#creates master list
    reader=csv.reader(contents)#reads file
    if skipHeader:
        next(reader)
    for row in reader:
        student=[]#creates sublists
        student.append(row[NAME])
        student.append(row[GPA])
        records.append(student)#adds sublist to master list
    return records
    
def swap(a,b):
    '''swaps the gpa position with name position for filtering'''
    temp=a
    a=b
    b=temp
    return a,b

def orderGPA(records):
    '''uses swap function and lists of lists to organize data by gpa'''
    for gpa in records:
        gpa[0], gpa[1]=swap(gpa[0], gpa[1])
    records.sort()#sort list
    print(spacing.format("\nGPA: ","Student Name: "))
    print(spacing.format("---","-------------"))
    for gpa in records:
        print(spacing.format(gpa[0],gpa[1]))
    
def selectMenu(filename,contents):
    '''Displays menu, Retrieves selection from user.'''
    title="--File Menu--".center(80)#formats menu title
    print(title,"\n1. Load CSV \n2. Create Pickle File\n3. Load Pickle File\n4. Name Sort \n5. GPA Sort \n6.Exit")
    #Loop--allows user to stay in menu while moving through menu selections.
    do='y'
    choice=1
    while do.lower()=='y' or choice in (range(1,7)):
        choice=str(input("\nMake a selection: "))
        if choice=='1' :
            print("-IMPORTING FILE-\nFile Uploaded")
        elif choice=='2':
            saveFile(contents)
            print(filename,"has been successfully saved.")
        elif choice=='3':
            try:
                loadFile()
                print(filename," has been successfully loaded.")
            except FileNotFoundError:
                print("Create a pickled file before attempting to unpickle the file.")
                selectMenu(filename, contents)
        elif choice=='4':
            records=reader(contents)
            print(spacing.format("\nStudent Name: "," GPA"))
            print(spacing.format("------------","---"))
            for student in records:
                print(spacing.format(student[0],student[1]))
            selectMenu(filename, contents)
        elif choice=='5':
            try:
                orderGPA(records)
            except UnboundLocalError:
                records=reader(contents)
                orderGPA(records)
                selectMenu(filename,contents)
        elif choice==str(6):
            print("Exit Program:  Goodbye.")
            break
        else:
            print("Enter a valid choice.")
            selectMenu(filename,contents)
        do=input("Choose from menu options? Enter: (y/n) ")
        if do.lower()!='y' and do.lower()!='n':
            print("Enter a valid choice.")
            selectMenu(filename,contents)
        elif do.lower()=='n':
            print("Exit Programa:  Goodbye.")
            break

main()
